<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src='/js/jquery-3.1.1.min.js'></script>
</head>
<body>
    <form action="" id='it'>
    <input type="hidden" name='laravel_id' value='<?php echo e($up->laravel_id); ?>'>
        商品名称：<input type="text" name='laravelname' value='<?php echo e($up->laravelname); ?>'><br>
        商品类别：<select name="laravelcart">
                        <?php $__currentLoopData = $cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option name='laravelcart' value="<?php echo e($value->laravel_id); ?>" checked><?php echo e($value->laravel_cart); ?></option> 
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </select><br>
        商品详情：<input type="text" name='laravelxiang' value='<?php echo e($up->laravelxiang); ?>'><br>
        
        是否热卖：<input type="radio" name='laravelre' value='1' checked>是
                 <input type="radio" name='laravelre' value='2'>否
                 <br>
        是否上架：<input type="radio" name='laravelshang' value='1' checked>是
                 <input type="radio" name='laravelshang' value='2'>否
                 <br>
                 <!-- <button onclick="javascript:;" id='is'>确定</button> -->
                 <input type="button" id='xiou' value='修改'>
    </form>
</body>
</html>

<script>
    $('#xiou').click(function(){
        var laravel_id=$("input[name='laravel_id']").val();//id
        var laravelname=$("input[name='laravelname']").val();//名称
        var laravelcart=$("option[name='laravelcart']:checked").val();
        var laravelxiang=$("input[name='laravelxiang']").val();//详情
        var laravelre=$("input[name='laravelre']:checked").val();//热卖
        var laravelshang=$("input[name='laravelshang']:checked").val();//上架
        var data={laravel_id:laravel_id,laravelname:laravelname,laravelcart:laravelcart,laravelxiang:laravelxiang,laravelre:laravelre,laravelshang:laravelshang}
        $.ajax({
            type:"post",
            url:"updateinfo",
            data:data,
            datatype:"json",
            success:function(msg){
                // console.log(msg)
                // return false;
                if(msg==1){
                   alert('修改成功');
                   location.href='list';
                }else{
                    alert('修改失败');
                    location.href='list';
                }
            }
        }
        )
    });
</script>