<script src='/js/jquery-3.1.1.min.js'></script>
<table >
    <tr>
        <td>商品id</td>
        <td>商品名称：</td>
        <td>商品类别：</td>
        <td>商品详情：</td>
        <td>是否热卖：</td>
        <td>是否上架：</td>
        <td>操作</td>
    </tr>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td value='<?php echo e($value->laravel_id); ?>'><?php echo e($value->laravel_id); ?></td>
      <td value='<?php echo e($value->laravelname); ?>'><?php echo e($value->laravelname); ?></td>
      <td value='<?php echo e($value->laravel_id); ?>'><?php echo e($value->laravel_id); ?></td>
      <td value='<?php echo e($value->laravelxiang); ?>'><?php echo e($value->laravelxiang); ?></td>
      <td value='<?php echo e($value->laravelre); ?>'><?php echo e($value->laravelre); ?></td>
      <td value='<?php echo e($value->laravelshang); ?>'><?php echo e($value->laravelshang); ?></td>
     <td><a href="update?laravel_id=<?php echo e($value->laravel_id); ?>">编辑</a>|<a href="delete?laravel_id=<?php echo e($value->laravel_id); ?>">删除</a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo e($data->links()); ?>