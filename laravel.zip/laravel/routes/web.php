<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::any("add","lise@add");

Route::any("aretc","wodecontroller@index");

Route::any('acrt',"wodecontroller@add");
Route::any('laraveladd','wodecontroller@laraveladd');
Route::any('list','wodecontroller@list');
Route::any('delete',"wodecontroller@delete");
Route::any('update',"wodecontroller@update");
Route::any('updateinfo',"wodecontroller@updateinfo");
Route::any('index',"Index\Indexcontroller@index");
Route::any('login',"User\Usercontroller@login");
Route::any('register',"User\Usercontroller@register");
Route::any('doadd',"User\Usercontroller@doadd");
Route::any('dologin',"User\Usercontroller@dologin");
Route::any('tel',"User\Usercontroller@tel");
Route::any("getcode","User\Usercontroller@getcode");
Route::any("demo","Index\Indexcontroller@demo");
Route::any('addindex',"Index\Indexcontroller@addindex");
Route::any('goodsli',"Goods\GoodsController@goodsli");
Route::any('allshops',"Goods\GoodsController@allshops");
Route::any('addallshops',"Goods\GoodsController@addallshops");
Route::any('test',"Goods\GoodsController@test");
Route::any('shopcontent',"Goods\GoodsController@shopcontent");
Route::any('cate_goods',"Goods\GoodsController@cate_goods");

Route::any('addshop',"Goods\GoodsController@addshop");
Route::any('shopcart',"Goods\GoodsController@shopcart");
Route::any('carshop',"Shop\ShopcartController@carshop");
Route::any('shpcor',"Shop\ShopcartController@shpcor");
Route::any('shopcar',"Shop\ShopcartController@shopcar");
Route::any('delet',"Shop\ShopcartController@delet");
Route::any('adelete',"Shop\ShopcartController@adelete");

Route::any('settlement',"Shop\ShopcartController@settlement");
Route::any('order',"Shop\ShopcartController@order");
Route::any('aettlement',"Shop\ShopcartController@aettlement");
Route::any('set',"settlement\SetController@set");
Route::any('writeaddr',"settlement\SetController@writeaddr");
Route::any('writace',"settlement\SetController@writace");
Route::any('address',"settlement\SetController@address");
Route::any('del',"settlement\SetController@del");
