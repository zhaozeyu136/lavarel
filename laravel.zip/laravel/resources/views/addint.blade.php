<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <script src='/js/jquery-3.1.1.min.js'></script>
</head>
<body>
    <form action="" id='it'>
        商品名称：<input type="text" name='laravelname'><br>
        商品类别：<select name="laravelcart">
                        @foreach ($cate as $value)
                           <option name='laravelcart' value="{{$value->laravel_id}}" checked>{{ $value->laravel_cart }}</option> 
                        @endforeach
                 </select><br>
        商品详情：<input type="text" name='laravelxiang'><br>
        是否热卖：<input type="radio" name='laravelre' value='1' checked>是
                 <input type="radio" name='laravelre' value='2'>否
                 <br>
        是否上架：<input type="radio" name='laravelshang' value='1' checked>是
                 <input type="radio" name='laravelshang' value='2'>否
                 <br>
                 <!-- <button onclick="javascript:;" id='is'>确定</button> -->
                 <input type="button" id='is' value='确定'>
    </form>
</body>
</html>
<script>
    $("#is").click(function(){
        //获取数据
        var laravelname=$("input[name='laravelname']").val();//名称
        var laravelcart=$("option[name='laravelcart']:checked").val();
        // var laravelcart=$("input[name='laravelcart']").val();
        var laravelxiang=$("input[name='laravelxiang']").val();//详情
        var laravelre=$("input[name='laravelre']:checked").val();//热卖
        var laravelshang=$("input[name='laravelshang']:checked").val();//上架
        var data={laravelname:laravelname,laravelcart:laravelcart,laravelxiang:laravelxiang,laravelre:laravelre,laravelshang:laravelshang}
        // var data=$('#it').serialize();
        $.ajax({
            type:"post",
            url:"laraveladd",
            data:data,
            datatype:"json",
            success:function(msg){
                if(msg==1){
                    alert('添加成功');
                   location.href='list';
                }else{
                    alert('添加失败');
                }
            }
        }
        )
    });
</script>