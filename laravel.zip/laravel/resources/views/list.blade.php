<script src='/js/jquery-3.1.1.min.js'></script>
<table >
    <tr>
        <td>商品id</td>
        <td>商品名称：</td>
        <td>商品类别：</td>
        <td>商品详情：</td>
        <td>是否热卖：</td>
        <td>是否上架：</td>
        <td>操作</td>
    </tr>
    @foreach ($data as $value)
    <tr>
      <td value='{{$value->laravel_id}}'>{{$value->laravel_id}}</td>
      <td value='{{$value->laravelname}}'>{{$value->laravelname}}</td>
      <td value='{{$value->laravel_id}}'>{{$value->laravel_id}}</td>
      <td value='{{$value->laravelxiang}}'>{{$value->laravelxiang}}</td>
      <td value='{{$value->laravelre}}'>{{$value->laravelre}}</td>
      <td value='{{$value->laravelshang}}'>{{$value->laravelshang}}</td>
     <td><a href="update?laravel_id={{$value->laravel_id}}">编辑</a>|<a href="delete?laravel_id={{$value->laravel_id}}">删除</a></td>
    </tr>
    @endforeach
</table>
{{ $data->links() }}