<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class order extends Model
{
    protected $table = 'shop_order';
    protected $primaryKey= 'order_id';
    // protected $fillable = ['goods_name','goods_cate'];
    public $timestamps = false;
}