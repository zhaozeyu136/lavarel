<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class detail extends Model
{
    protected $table = 'shop_order_detail';
    protected $primaryKey= 'id';
    // protected $fillable = ['goods_name','goods_cate'];
    public $timestamps = false;
}