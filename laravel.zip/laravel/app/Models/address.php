<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class address extends Model
{
    protected $table = 'shop_order_address';
    protected $primaryKey= 'address_id';
    // protected $fillable = ['goods_name','goods_cate'];
    public $timestamps = false;
}