<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class car extends Model
{
    protected $table = 'shop_car';
    protected $primaryKey= 'c_id';
    protected $fillable = ['goods_id','uid','goods_num','status','creattime'];
    public $timestamps = false;
}