<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class goods extends Model
{
    protected $table = 'shop_goods';
    protected $primaryKey= 'goods_id';
    protected $fillable = ['goods_name','goods_cate'];
    public $timestamps = false;
}