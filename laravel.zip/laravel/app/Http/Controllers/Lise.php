<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class Lise extends Controller
{
    public function add(){
        echo 22222;
    }
}
