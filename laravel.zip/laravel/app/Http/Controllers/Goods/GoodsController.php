<?php

namespace App\Http\Controllers\Goods;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\Models\goods;
use App\Models\car;
use App\Models\user;
class GoodsController extends Controller
{
    protected static $arrCate=array();
    public function goodsli(){
        return view('goods.goodsli');
    }

    public function allshops(){
        $cate=DB::table('shop_cate')->where('pid',0)->get();
        $goods=DB::table('shop_goods')->get();
        return view('goods.allshops',['cate'=>$cate],['goods'=>$goods]);
    }


    public function cate_goods(Request $request){
      $cate_id=$request->input('cate_id');
      $this->get($cate_id);
      $cate_id=self::$arrCate;
      //exit;
      $info=DB::table('shop_goods')->whereIn('cate_id',$cate_id)->get()->toArray();
      return view('goods.cate_goods',['cate'=>$info]);
    }

    public function get($cate_id){
        $add=DB::table('shop_cate')->select("cate_id")->where('pid',$cate_id)->get();
        if(count($add) !=0 ){
            foreach($add as $key=>$value){
                $cateId=$value->cate_id;
                $id = $this->get($cateId);
                self::$arrCate[]=$id;
            }
        }

        if(count($add) == 0){
           return $cate_id;
        }
    }

    // public function addallshops(Request $request){
        //     $id=$request->input('cate_id');
        //    if($id=='aie'){
        //         $arr=DB::table('shop_goods')->get();
        //         return $arr;
        //    }
        //     $where=[
        //         'cate_id'=>$id
        //     ];
        //     $arr=DB::table('shop_goods')->where($where)->get();
        //     return $arr;
        // }
        // public function doallshops(Request $request){
        //     $data=$request->filter_inpu();
        // }
        // public function shopcontent(Request $request){
        //     return view('goods.shopcontent');
        // }
    public function shopcontent(Request $request){
        $goods_id=$request->input('goods_id');
        $where=[
            'goods_id'=>$goods_id
        ];
        $res=DB::table('shop_goods')->where($where)->get();
        return view('goods.shopcontent',['res'=>$res]);
    }

    

    public function addshop(Request $request){
        $goods_id=$request->input('goods_id');
        $where=[
            'goods_id'=>$goods_id
        ];
        $res=goods::where($where)->first();
        $goods_name=$res['goods_name'];
        $status=1;
        if(!empty(session('uid'))){//判断是否登陆
           $where=[
               'goods_id'=>$goods_id,
               'is_best'=>1
           ];
          $arr=goods::where($where)->first();
           if(!empty($arr)){
                if($arr['goods_number']>0){//判断库存是否充足
                    $goods_id=$arr['goods_id'];
                    $uid=session('uid');
                    $user=user::where('uid',$uid)->first();
                    $where=[
                        'uid'=>$user['uid'],
                        'goods_id'=>$goods_id
                    ];
                    $car=car::where($where)->first();
                    if(!empty($car)){//判断商品是否在购物车中
                        if($car['goods_num']>$arr['goods_number']){
                            $add=[
                                'status'=>0,
                                'msg'=>'该商品库存不足'
                            ];
                            return $add;
                        }else{
                            $data=[
                                'goods_id'=>$goods_id,
                                'uid'=>$user['uid'],
                                'goods_num'=>$car['goods_num']+1,
                                'creattime'=>time(),
                                'status'=>$status,
                                ]; 
                                $res = car::where('c_id',$car['c_id'])->update($data);
                        }
                    }else{
                        $data=[
                            'goods_id'=>$goods_id,
                            'uid'=>$user['uid'],
                            'goods_num'=>1,
                            'creattime'=>time(),
                            'status'=>$status,
                            ];
                            $res = car::insert($data); 
                    }
                    if($res){
                        $add = [
                            'status'=>2,
                            'msg'=>'添加成功'
                        ];
                        return $add;
                    }else{
                        $add = [
                            'status'=>0,
                            'msg'=>'发生系统错误请联系管理员'
                        ];
                        return $add;
                    }
                }else{
                    $add = [
                        'status'=>0,
                        'msg'=>'抱歉该商品库存不足'
                    ];
                    return $add;
                }
           }else{
            $add = [
                'status'=>0,
                'msg'=>'该商品已下架'
            ];
            return $add;
        }
        }else{
            $add=[
                'status'=>1,
                'msg'=>'请登陆后再添加商品'
            ];
            return $add;
        }
       
    }

    //购物车
    public function shopcart(){
        $car=car::join('shop_goods','shop_car.goods_id','=','shop_goods.goods_id')->where('status',1)->get();
        return view('goods.shopcart',['car'=>$car]);
    }

    // public function addcart(Request $request){
        
    // }
}
