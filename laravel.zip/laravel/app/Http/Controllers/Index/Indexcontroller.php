<?php

namespace App\Http\Controllers\Index;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
class Indexcontroller extends Controller
{
    public function Index(){
        $arr=DB::table('shop_goods')->where('Recommend',1)->paginate(2);
        $add=DB::table('shop_goods')->where('cai',1)->paginate(8);
        return view('index.index',['arr'=>$arr],['add'=>$add]);
    }
    
    public function addindex(Request $request){
        $arr=array();
        $page=$request->input('page',1);
        $pageNum=2;
        $offset=($page-1)*$pageNum;
        $arrDataInfo=DB::table('shop_goods')->offset($offset)->limit($pageNum)->get();//每页的数据
        $totalData=DB::table('shop_goods')->count();//总条数
        $pageTotal=ceil($totalData/$pageNum);//总页数

        $objview=view("goods.goodsli",['info'=>$arrDataInfo]);

        $content=response($objview)->getContent();
        $arr['info']=$content;
        $arr['page']=$pageTotal; 
        return $arr;
    }
    public function demo(){
        return view("index.demo");
    }
}
