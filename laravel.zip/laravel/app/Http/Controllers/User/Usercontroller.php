<?php

namespace App\Http\Controllers\User;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\user;
use Illuminate\Support\Facades\DB;
class Usercontroller extends Controller
{
    public function register(){
        return view('user.register');
    }
    public function doadd(Request $request){
        $arr=$request->input();
        // $bol=DB::table('user')->where('tel'==$arr['tel'])->select();
            $tel=$arr['tel'];
            $pwd=$arr['pwd'];
            $conpwd=$arr['conpwd'];
            $code=$arr['code'];
        if($pwd!=$conpwd){
            $arr=array(
                'static'=>0,
                'msg'=>'密码不一致'
            );
            return $arr;
        }
        //手机号验证唯一
        $arr=User::where('tel',$tel)->first();
            if(!empty($arr)){
                $arr=array(
                    'static'=>0,
                    'msg'=>'手机号已存在'
                );
                return $arr;
            }
        $time=time();
        //验证验证码
        $sql="select * from user_info where tel=$tel and code=$code and timeout>$time and `status`=1";
        $arrinfo=DB::select($sql);
        if(empty($arrinfo)){
            $arr=array(
                'static'=>0,
                'msg'=>'验证码错误'
            );
            return $arr;
        }
        //入库
            $pwd=md5($pwd);
            $arrinfo=array(
                'tel'=>$tel,
                'pwd'=>$pwd
            );
            $bol=DB::table('user')->insert($arrinfo);
            if(!empty($bol)){
                $arr=array(
                    'static'=>1,
                    'msg'=>'注册成功'
                );
                return $arr;
            }else{
                $arr=array(
                    'static'=>0,
                    'msg'=>'注册失败'
                );
                return $arr;
            }
    }
    
    public function login(){
        return view('user.login');
    }

    public function dologin(Request $request){
        $arr=$request->input();
        $tel=$arr['name'];
        $pwd=$arr['pwd']; 
        $pwd=md5($pwd);  
        $where=[
            'tel'=>$tel,
            'pwd'=>$pwd
        ];  
        // if('tel'!=$tel){
        //     $arr=array(
        //         'static'=>0,
        //         'msg'=>'账号或密码有误'
        //     );
        //     return $arr;
        // }
         $user=DB::table('user')->where($where)->first();
        if($user){
           $id=$user->uid;
           $name=$user->tel;
           session(['uid'=>$id,'name'=>$name]);
           $arr=array('static'=>1,'msg'=>'登录成功'); 
           return $arr;
        }else{
            $arr=array('static'=>0,'msg'=>'登录失败');
             return $arr;
        }
    }
    public function tel(Request $request){
        $obj=new \send();
        $tel="17610400026";
        $obj->show($tel);
    }
    public function getcode(Request $request){
        $tel=$request->input('tel');
        //生成验证码
        $num = rand(1000,9999);
        $obj=new \send();
        $bol=$obj->show($tel,$num);
        // print_r($bol);exit;
        if($bol==100){
            $arr=array(
                'tel'=>$tel,
                'code'=>$num,
                'timeout'=>time()+10000,
                'status'=>1
            );
            $bol=DB::table('user_info')->insert($arr);
            var_dump($bol);
        }
    }
}
