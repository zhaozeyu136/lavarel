<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;

class Wodecontroller extends Controller
{
   public function index(Request $request){
    //    $spl='insert into shop_attr values("1","nan")' ;
    //    $bol=DB::insert($spl);

    // $sql="select * from shop_attr"; 
    // $bol=DB::select($sql);
   
    // $sql="update  shop_attr set name='long' where id=1";
    // $bol=DB::update($sql);

    // $sql="delete from shop_attr where id='1'";
    // $bol=DB::delete($sql);
    // print_r($bol);
   }

   public function add(Request $request){
        $arr = DB::table('laravel_cart')->get();
        return view('addint',['cate'=>$arr]);
   }

   public function laraveladd(Request $request){
      $arrData=array();
        $sql=$request->input();
    //    print_r($sql);exit;
        $arrData['laravelname']=trim($sql['laravelname']);
        $arrData['laravelcart']=intval($sql['laravelcart']);
        $arrData['laravelxiang']=trim($sql['laravelxiang']);
        $arrData['laravelre']=intval($sql['laravelre']);
        $arrData['laravelshang']=intval($sql['laravelshang']);
        $res=DB::table('laravel')->insert($sql);
       if($res){
            return 1;
       }else{
            return 0;
       }
   
   }
   public function list(Request $request){
        // $arr=DB::table('laravel')->get();
        // 逻辑
        $addinfo = DB::table('laravel')->paginate(2);
        return view('list',['data'=>$addinfo]);
   }
   public function delete(Request $request){
        $arr=$request->input('laravel_id');
        $where=[
            'laravel_id'=>$arr
        ];
        $res=DB::table('laravel')->where($where)->delete();
        if($res){
            $url=url('list');
            return redirect($url);
        }else{
            $url=url('list');
            return redirect($url);
        }
   }
   public function update(Request $request){
    $arr = DB::table('laravel_cart')->get();
    
        
    $arrinfo=$request->input('laravel_id');
        $where=[
            'laravel_id'=>$arrinfo
        ];
        $res=DB::table('laravel')->where($where)->first();
        // print_r($res);exit;
        return view('update',['up'=>$res,'cate'=>$arr]);  
   }
   public function updateinfo(Request $request){
        $arr=$request->input();
        // print_r($arr);exit;
        $where=[
            'laravel_id'=>$arr['laravel_id']
        ];
        $res=DB::table('laravel')->where($where)->update($arr);
        // dd($res);exit;
        if($res){
            return 1;
        }else{
            return 0;
        }
   }
}
  