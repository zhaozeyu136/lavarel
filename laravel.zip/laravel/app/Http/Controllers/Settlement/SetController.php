<?php

namespace App\Http\Controllers\Settlement;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\Models\goods;
use App\Models\car;
use App\Models\user;
use App\Models\order;
use App\Models\detail;
use App\Models\address;
class SetController extends Controller
{
    public function set(Request $request){
        
        $uid=session('uid');
        
        $re=address::where('uid',$uid)->get()->toArray();
        // print_r($re);exit;
        $ad=address::where('post_code',1)->get()->toArray();
       
        if(empty($re)){
            $arr=[
                'status'=>0,
                'msg'=>'请添加地址'
            ];
            return json_encode($arr);
        }else{
           
        };
        if(empty($ad)){
            $arr=[
                'status'=>2,
                'msg'=>'请先选择默认地址'
            ];
            return json_encode($arr);
        }
    } 
    
    
    public function writeaddr(Request $request){
        $id=$request->input();
        // return $id;
        return view('shop.writeaddr',$id);
    }


    public function writace(Request $request){
            $data=$request->input();
            $id=$data['li'];
            $post_code=$data['fault'];
            if($post_code==''){
                $post_code=0;
            }
            $uid=session('uid');
            // print_r($uid);exit;
            $snk=[
                'order_receive_name'=>$data['name'],
                'receive_phone'=>$data['tel'],
                'region'=>$data['demo1'],
                'receive_address'=>$data['addr'],
                'uid'=>$uid,
                'ctime'=>time(),
                'order_id'=>$id,
                'post_code'=>$post_code
            ];
            $res=address::insert($snk);
            if(!empty($res)){
                $arr=[
                    'status'=>1,
                    'msg'=>'请先选择默认地址'
                ];
                return $arr;
            }
    }


    public function address(Request $request){
        $arr=address::get();
        return view('shop.address',['arr'=>$arr]);
    }
    public function del(Request $request){
        $dele=$request->input();
        $arr=address::where('address_id',$dele)->delete();
        if(!empty($arr)){
            $arr=[
                'status'=>1,
                'msg'=>'删除成功'
            ];
            return $arr;
        }else{
            $arr=[
                'status'=>0,
                'msg'=>'删除失败'
            ];
            return $arr; 
        }
        
    }
}
