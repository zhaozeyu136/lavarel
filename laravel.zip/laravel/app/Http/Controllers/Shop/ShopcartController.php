<?php

namespace App\Http\Controllers\Shop;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\Models\goods;
use App\Models\car;
use App\Models\user;
use App\Models\order;
use App\Models\detail;
class ShopcartController extends Controller
{
    public function carshop(Request $request){
        $data=$request->input();
        $where=[
            'goods_id'=>$data['goods_id']
        ];
        $re=$data['re']+1;
        $goods=goods::where($where)->first()->toArray();
        
        $goods_number=$goods['goods_number'];
       $cart=[
           'c_id'=>$data['c_id']
       ];
        $car=car::where($cart)->first()->toArray();
        $goods_num=$car['goods_num'];

        if($goods_number<=$data['re']){
                $arr=[
                    'status'=>1,
                    'msg'=>'库存不足',
                    'num'=>$goods_number
                ];
                return $arr;
        }else{
                $car=car::where($cart)->update(['goods_num'=>$re]);
                $car=[
                    'status'=>0,
                    'msg'=>$goods_number
                ];
                return $car;
        }
         
    }

    public function shpcor(Request $request){
        $data=$request->input();
        $where=[
            'goods_id'=>$data['goods_id']
        ];
        $rs=$data['rs']-1;
        $goods=goods::where($where)->first()->toArray();
        $goods_number=$goods['goods_number'];
        $cart=[
            'c_id'=>$data['c_id']
        ];
       $car=car::where($cart)->first()->toArray();
       $goods_num=$car['goods_num'];
       if($rs<=0){
            $arr=[
                'status'=>1,
                'msg'=>'商品不能低于0',
                'num'=>1
            ];
            return $arr;
        }else{
                $car=car::where($cart)->update(['goods_num'=>$rs]);
                $car=[
                    'status'=>0,
                    'msg'=>''
                ];
            return $car;
        }

    }

    public function shopcar(Request $request){
        $data=$request->input();
        $where=[
            'goods_id'=>$data['goods_id']
        ];
        $ri=$data['ri'];
        
        $goods=goods::where($where)->first()->toArray();
        $goods_number=$goods['goods_number'];
       $cart=[
           'c_id'=>$data['c_id']
       ];
       $car=car::where($cart)->first()->toArray();
       $goods_num=$car['goods_num'];
       if($goods_number<=$data['ri']){
            $arr=[
                'status'=>1,
                'msg'=>'数据有误',
                'num'=>$goods_number,
            ];
            // $car=car::where($cart)->update(['goods_num'=>$ri]);
            return $arr;
        }else if($ri<=0){
            $arr=[
                'status'=>1,
                'msg'=>'数据有误',
                'num'=>1,
            ];
            return $arr;
        }else{
                $car=car::where($cart)->update(['goods_num'=>$ri]);
                $arr=[
                    'status'=>0,
                    'msg'=>''
                ];
            return $arr;
        }

    }

    public function delet(Request $request){
        $data=$request->input();
        // DB::table()->where()->get();
        $status=DB::table('shop_car')->where('c_id',$data['c_id'])->update(['status'=>0,'goods_num'=>0]);
        if(!empty($status)){
            $arr=[
                'status'=>1,
                'msg'=>'删除成功'
            ];
            return $arr;
        }else{
            $arr=[
                'status'=>0,
                'msg'=>'删除失败'
            ];
           return $arr;
        }
        
    }

    public function adelete(Request $request){
        $snk=$request->input('snk');
        $dele=car::whereIn('c_id',$snk)->update(['status'=>0,'goods_num'=>0]);
        if(!empty($dele)){
            $arr=[
                'status'=>1,
                'msg'=>'删除成功'
            ];
            return $arr;
        }else{
            $arr=[
                'status'=>0,
                'msg'=>'删除失败'
            ];
            return $arr;
        }

    }

    public function settlement(Request $request){
        $snk=$request->input('snk');
        $uid=session('uid');
        $user=user::where('uid',$uid)->first()->toArray();
        $uid=$user['uid'];
        $where=[
            'uid'=>$uid
        ];
       $order=date("YmdHis",time()).rand(10000,99999);
       $snk = explode(',', $snk);
       $arr=car::whereIn('c_id',$snk)->join('shop_goods','shop_car.goods_id','=','shop_goods.goods_id')->get();
        $many=[];
        foreach($arr as $v){
            array_push($many,$v['goods_num']*$v['shop_price']);
        }
        $my=array_sum($many);
        $date = [
            'order_no'=>$order,
            'uid'=>$uid,
            'order_amount'=>$my,
            'status'=>1,
            'ctime'=>time(),
        ];
        $res = order::insertGetId($date);
        if(is_numeric($res)){
            $up = [
                'status'=>2,
                'goods_num'=>0
            ];
            $ask = car::whereIn('c_id',$snk)->update($up);
            $this->payid($res,$snk,$uid,$order);
        }
        $ew=detail::where('status',2)->get();
       return view('shop.settlement',['arr'=>$arr,'my'=>$my,'ew'=>$ew,'order_id'=>$res]);
    }

    public function payid($id,$snk,$uid,$order){
      $add=car::whereIn('c_id',$snk)->join('shop_goods','shop_car.goods_id','=','shop_goods.goods_id')->get()->toArray();
      foreach($add as $v){
            $del=[
                'order_id'=>$id,
                'uid'=>$uid,
                'goods_id'=>$v['goods_id'],
                'buy_number'=>$v['goods_num'],
                'goods_name'=>$v['goods_name'],
                'goods_price'=>$v['shop_price'],
                'status'=>2,
                'order_no'=>$order,
                'ctime'=>time()
            ];
         $res=detail::insert($del);
        }
    }
    public function aettlement(Request $request){
        $snk=$request->input();
        if(!empty(session('uid'))){
            $add=car::whereIn('c_id',$snk)->join('shop_goods','shop_car.goods_id','=','shop_goods.goods_id')->get()->toArray();

           foreach($add as $k=>$v){
               if($v['goods_num']>=$v['goods_number']){
                    $arr=[
                        'status'=>0,
                        'msg'=>'商品库存不足'
                    ];
                    return $arr;
               }else{
                    $arr=[
                        'status'=>1,
                        'msg'=>'结算'
                    ];
                    return $arr;
               }
           }
        }else{
                $arr=[
                    'status'=>0,
                    'msg'=>'请登陆后再添加订单'
                ];
                return $arr;
        }
        
    }

    
    // public function settlement(Request $request){
    //     $ew=detail::where('status',2)->get();
    //     return view('shop.settlement',['ew'=>$ew]);
    // }
}
